/* -tb codeing
  https://www.takup.net/
*/


//creating EventListener Button Click for all Add to Cart Button
var carts = document.querySelectorAll('.add-cart');

for (let i = 0; i < carts.length; i++) {
  carts[i].addEventListener('click', () => {
    cartNumbers(products[i]);
    totalCost(products[i]);
  });
}

function cartNumbers(product) {
  var cartNumber = localStorage.getItem('cartNumbers')
  cartNumber = parseInt(cartNumber);

  if (cartNumber) {
    //checking if item to be add already exist in cartItems
    var cartItems = localStorage.getItem('productsInCart');
    cartItems = JSON.parse(cartItems);
    var checker = false;

    //loop throuht the cartItems to find item
    for(var key of Object.keys(cartItems)){
      console.log(`${key} => ${cartItems[key]}`);
      if(product.tag == `${key}`){
        checker =true;
      }
    }

    if(checker === false){
      //new item is being added
      localStorage.setItem('cartNumbers', cartNumber + 1);
      document.querySelector('.cart span').textContent = cartNumber + 1;
    }  
  } else {
    //adding first item to cart
    localStorage.setItem('cartNumbers', 1);
    document.querySelector('.cart span').textContent = 1;
  }

  setItems(product);
}


function setItems(product) {
  var cartItems = localStorage.getItem('productsInCart');
  cartItems = JSON.parse(cartItems);

  if (cartItems != null) {
    //For new item to cartItems
    if (cartItems[product.tag] == undefined) {
      cartItems = {
        ...cartItems,
        [product.tag]: product
      }
    }
    //update new & old cartItems
    cartItems[product.tag].incart += 1;
  } else {
    //Adding first item to cartItems
    product.incart = 1;
    cartItems = {
      [product.tag]: product
    }
  }
  localStorage.setItem('productsInCart', JSON.stringify(cartItems));
}

function totalCost(product){
  var cartTotal = localStorage.getItem('totalCost');

  if (cartTotal != null) {
    cartTotal = parseInt(cartTotal);
    localStorage.setItem('totalCost', product.price + cartTotal);
  }else{
    localStorage.setItem('totalCost', product.price);
  }
}

function onLoadCartNumbers() {
  //get cartNumbers and cartitems form localStorage
  var cartNums = localStorage.getItem('cartNumbers');

  if (cartNums) {
    document.querySelector('.cart span').textContent = cartNums;
  }
}

function displayCart(){
  var cartItems  = localStorage.getItem('productsInCart');
  cartItems = JSON.parse(cartItems);
  var totalCost = localStorage.getItem('totalCost');

  var productContainer = document.querySelector('.products');

  if(cartItems && productContainer){

    productContainer.innerHTML = '';
    Object.values(cartItems).map(item => {
      //using backticks
      productContainer.innerHTML +=  `
         <div class="row">
          <div class="product">
             <ion-icon class="product-remove ${item.tag}" name ="close-circle"></ion-icon>
             <img src="./images/${item.tag}.jpg" >
             <span>${item.name}</span>
          </div>
          <div class="product-price" >GHS ${item.price} </div>
          <div class="product-quantity">
              <ion-icon class="decrease-btn ${item.tag}" name="arrow-dropleft-circle"></ion-icon>
              <span class=""> ${item.incart} </span>
              <ion-icon class="increase-btn ${item.tag}" attributes ="tstbtn" name="arrow-dropright-circle"></ion-icon>
          </div>
          <div class="product-total" >GHS ${item.price * item.incart}.00 </div>
         </div>
       `;

    });

    productContainer.innerHTML += `
          <div class="cart-total">
             <div class="cart-desc">
             <b>  TOTAL </b>
             </div>
             <div class="cart-figure">
                <b> GHS ${totalCost}.00 </b>
             </div>
          </div>
    `;
  }
}


function testme(){
  alert('test me');
}


onLoadCartNumbers();
displayCart();
