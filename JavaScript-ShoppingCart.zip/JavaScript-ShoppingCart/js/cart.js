/* -tb codeing
  https://www.takup.net/
*/

/* -tb codeing
  https://www.takup.net/
*/

//creating EventListener all increase-quantity button in Cart
var increaseBtns = document.querySelectorAll('.increase-btn');
for(let i =0; i < increaseBtns.length; i++){
  increaseBtns[i].addEventListener('click', () => {
    //get tag name for item
    var tagItem = increaseBtns[i].classList[1];
    increaseItemQuantity(tagItem);
  });
}

function increaseItemQuantity(tagItem){
  var cartItems = localStorage.getItem('productsInCart');
  cartItems = JSON.parse(cartItems);
  var cartTotal = localStorage.getItem('totalCost');

     //Calculations of additional cost to total cart cost
     var newTotalCost = parseInt(cartTotal) + cartItems[tagItem].price ;

     //set limit for increament
     if(cartItems[tagItem].incart < 40){
       //Update Cart
       localStorage.setItem('totalCost', newTotalCost);
       cartItems[tagItem].incart += 1;
       localStorage.setItem('productsInCart', JSON.stringify(cartItems));
       reload();
     }
}


//creating EventListener all decrease-quantity button in Cart
var decreaseBtns = document.querySelectorAll('.decrease-btn');
for(let i =0; i < decreaseBtns.length; i++){
  decreaseBtns[i].addEventListener('click', () => {
    //get tag name for item
    var tagItem = decreaseBtns[i].classList[1];
    decreaseItemQuantity(tagItem);
  });
}

function decreaseItemQuantity(tagItem){
  var cartItems = localStorage.getItem('productsInCart');
  cartItems = JSON.parse(cartItems);
  var cartTotal = localStorage.getItem('totalCost');

     //Calculations of additional cost to total cart cost
     var newTotalCost = parseInt(cartTotal) - cartItems[tagItem].price ;

     //set limit for decreament
     if(cartItems[tagItem].incart > 1){
       //Update Cart
       localStorage.setItem('totalCost', newTotalCost);
       cartItems[tagItem].incart -= 1;
       localStorage.setItem('productsInCart', JSON.stringify(cartItems));
       reload();
     }
}


//creating EventListener all remove product button in Cart
var removeBtns = document.querySelectorAll('.product-remove');
for(let i =0; i < decreaseBtns.length; i++){
  removeBtns[i].addEventListener('click', () => {
    //get tag name for item remove button class
    var tagItem = removeBtns[i].classList[1];
    removeItemFromCart(tagItem);
  });
}

function removeItemFromCart(tagName){
  var cartItems = localStorage.getItem('productsInCart');
  cartItems = JSON.parse(cartItems);
  var cartTotal = localStorage.getItem('totalCost');
  var cartNumber = localStorage.getItem('cartNumbers')

   //Calculating of new total cost after deduction removed product cost
   var removedItemCost = cartItems[tagName].incart * cartItems[tagName].price;
   var newTotalCost = parseInt(cartTotal) - removedItemCost;

    // filter out removed product with using tagname as key
    var newCartItems = filterObj( cartItems, function( key ) {
    	return key !== tagName
    });

    // update cart in localstorage
    localStorage.setItem('totalCost', newTotalCost);
    localStorage.setItem('productsInCart', JSON.stringify(newCartItems));
    localStorage.setItem('cartNumbers', cartNumber - 1);
    reload();
}

 /** filter object function */
  function filterObj( obj, predicate ) {
  	var result = {}, key;
  	for ( key in obj ) {
  		if ( obj.hasOwnProperty( key ) && predicate( key, obj[ key ] ) ) {
  			result[ key ] = obj[ key ];
  		}
  	}
  	return result;
  };


  function reload(){
    displayCart();
    window.location.reload(true);
  }
