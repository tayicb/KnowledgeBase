/* -tb codeing
  https://www.takup.net/
*/

//Creation product object
var products = [{
    name: "PS5 Console",
    tag: 'PS5',
    price: 6500,
    incart: 0
  },
  {
    name: 'Sony TV',
    tag: 'SonyTV',
    price: 2500,
    incart: 0
  },
  {
    name: 'Smart Watch',
    tag: 'SmartWatch',
    price: 1000,
    incart: 0
  },
  {
    name: 'HP Laptop',
    tag: 'HPLaptop',
    price: 2100,
    incart: 0
  },
  {
    name: 'Smart Phone',
    tag: 'SmartPhone',
    price: 950,
    incart: 0
  }
];
